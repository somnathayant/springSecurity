package com.mySecurity.secureResource.web.config;

import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.hibernate4.Hibernate4Module;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = { "com.mySecurity.secureResource" })
@Import({ SecurityConfig.class })
public class WebMvcConfigure extends WebMvcConfigurerAdapter {
	private Logger log = Logger.getLogger(WebMvcConfigure.class);

	public WebMvcConfigure() {
		log.info("WebMvcConfigure OBJECT CREATED");
	}

	
	public MappingJackson2HttpMessageConverter jacksonMessageConverter() {
		try {
			Jackson2ObjectMapperBuilder builder=new Jackson2ObjectMapperBuilder();
			builder.indentOutput(true);
			MappingJackson2HttpMessageConverter messageConverter = new MappingJackson2HttpMessageConverter(builder.build());
			ObjectMapper objectMapper = new ObjectMapper();
			objectMapper.registerModule(new Hibernate4Module());
			messageConverter.setObjectMapper(objectMapper);

			return messageConverter;
		} catch (Exception e) {
			log.error("jacksonMessageConverter ERROR : ", e);
			return null;
		}
	}

	@Override
	public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
		try {
			converters.add(jacksonMessageConverter());
			super.configureMessageConverters(converters);

		} catch (Exception e) {
			log.error("configureMessageConverters ERROR : ", e);
		}
	}
	
	@Bean
    public ViewResolver viewResolver() {
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setViewClass(JstlView.class);
        viewResolver.setPrefix("/WEB-INF/pages/");
        viewResolver.setSuffix(".jsp");
        return viewResolver;
    }


	
	
	
	
	/*MAIL CONFIGURATION*/
	@Bean
	public JavaMailSender getMailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();

		mailSender.setHost("smtp.gmail.com");
		mailSender.setPort(587);
		mailSender.setUsername("ayantsoft@gmail.com");
		mailSender.setPassword("ayantsoft12345");

		Properties javaMailProperties = new Properties();
		javaMailProperties.put("mail.transport.protocol", "smtp");
		javaMailProperties.put("mail.smtp.auth", "true");
		javaMailProperties.put("mail.smtp.starttls.enable", "true");
		javaMailProperties.put("mail.debug", "true");
		javaMailProperties.put("mail.smtp.ssl.trust", "smtp.gmail.com");

		mailSender.setJavaMailProperties(javaMailProperties);
		return mailSender;
	}
}