package com.ayantsoft.healthcare.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Service;

import com.ayantsoft.healthcare.dao.LoginDao;
import com.ayantsoft.hibernate.pojo.PatientMst;
import com.ayantsoft.hibernate.pojo.UserMst;

@Service
public class LoginService {

	@Autowired
	private LoginDao loginDao; 
    
public boolean userCheckInfo(UserMst userMst){
	 System.out.println(userMst.getUserName());
		return loginDao.checkUserInfo(userMst) ;
		
	}

}
