package com.ayantsoft.healthcare.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ayantsoft.healthcare.dao.PatientDao;
import com.ayantsoft.hibernate.pojo.CategoryMst;
import com.ayantsoft.hibernate.pojo.PatientMst;

@Service
public class PatientService {
	@Autowired
	private PatientDao patientDao; 
	
	public boolean patientSave(PatientMst patientMst){
		try{
			return patientDao.insertPatient(patientMst);
		}catch(Exception ex){
			return false;
		}
		
	}
	public List<CategoryMst> getCategory(){
		return patientDao.getCategory();
	}
	public List<PatientMst> getPatientList(){
		return patientDao.getPatientList();
	}
}
