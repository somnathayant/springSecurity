package com.ayantsoft.healthcare.controller;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ayantsoft.healthcare.service.PatientService;
import com.ayantsoft.hibernate.pojo.AddressMst;
import com.ayantsoft.hibernate.pojo.CategoryMst;

import com.ayantsoft.hibernate.pojo.PatientMst;
import com.lowagie.text.Document;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

@Controller
public class PatientController {

	@Autowired
	private PatientService patientService;

	@InitBinder
	public void dataBinding(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(
				dateFormat, false));}


	@RequestMapping("/patientReg")  
	public ModelAndView showPatientReg() { 

		ModelAndView mv=new ModelAndView();

		PatientMst patientMst=new PatientMst();
		AddressMst addressMst=new AddressMst();
		patientMst.setAddressMst(addressMst);
		List<CategoryMst> categoryList=patientService.getCategory();
		mv.setViewName("patientReg");
		mv.addObject("patientReg",patientMst);
		mv.addObject("categoryList",categoryList);
		return mv;
	}  
	
	@RequestMapping(value={"/savePatient"},method={RequestMethod.POST})  
	public ModelAndView savePatient(@ModelAttribute ("patientReg") PatientMst pMst) {  
		ModelAndView mv=new ModelAndView();
		System.out.println(pMst.getDoa());
		System.out.println(pMst.getDob());
		boolean isSaved=false;
		isSaved=patientService.patientSave(pMst);
		if(isSaved){
			mv.addObject("isSaved","Patient saved succesfully");
			mv.setViewName("confirmPage");
		}else{
			mv.addObject("isSaved","Patient not saved succesfully");
			mv.setViewName("confirmPage");
		}
		return mv;
	}  

	@RequestMapping(value={"/home"},method={RequestMethod.GET})  
	public ModelAndView getHome() {  
		ModelAndView mv=new ModelAndView();
		mv.setViewName("home");
		return mv;
	}  
	
	@RequestMapping("/getPatientList")  
	public ModelAndView getPatientList() {  
		ModelAndView mv=new ModelAndView();
		System.out.println("=====");
		List <PatientMst> pList=patientService.getPatientList();
		mv.addObject("patientList",pList);
		mv.setViewName("patientList");
		return mv;
	} 
	
	 @RequestMapping(value={"generatePdf"},method={RequestMethod.GET})  
	    public void pdf(HttpServletRequest request, HttpServletResponse response) {  
	 
	/*  response.setContentType("application/pdf");
   //Get the output stream for writing PDF object        
   OutputStream out=null;
	try {
		out = response.getOutputStream();
	 
		
		List <PatientMst> pList=patientService.getPatientList();
		   System.out.println(pList.size());
		
      Document document = new Document();
        //Basic PDF Creation inside servlet 
       PdfWriter.getInstance(document, out);
       document.open();
       Paragraph p=  new Paragraph("                       User Information ");
       document.add(p);
       Paragraph pBlank=  new Paragraph("                     ");
       document.add(pBlank);
       
       
       PdfPTable table = new PdfPTable(9); // 9 columns.
       PdfPCell cell1 = new PdfPCell(new Paragraph("Id"));
       PdfPCell cell2 = new PdfPCell(new Paragraph("Name"));
       PdfPCell cell3 = new PdfPCell(new Paragraph("Age"));
       PdfPCell cell4 = new PdfPCell(new Paragraph("DoB"));
       PdfPCell cell5 = new PdfPCell(new Paragraph("DoA"));
       PdfPCell cell6 = new PdfPCell(new Paragraph("Bed"));
       PdfPCell cell7 = new PdfPCell(new Paragraph("Gender"));
       PdfPCell cell8 = new PdfPCell(new Paragraph("State"));
       PdfPCell cell9 = new PdfPCell(new Paragraph("City"));
       PdfPCell cell10 = new PdfPCell(new Paragraph("City"));
       table.addCell(cell1);
       table.addCell(cell2);
       table.addCell(cell3);
       table.addCell(cell4);
       table.addCell(cell5);
       table.addCell(cell6);
       table.addCell(cell7);
       table.addCell(cell8);
       table.addCell(cell9);
       table.addCell(cell10);
       //System.out.println(pt.getName());
  	   for(PatientMst pt:pList){
  		 PdfPCell  cellId = new PdfPCell(new Phrase(" "+pt.getPatientId()));
   	     table.addCell(cellId);
    	 System.out.println(pt.getPatientId()); 
       }
       
       document.add(table);
       
       document.close();
  }catch(Exception ex){}
*/   
		 response.setContentType("application/pdf");
	      //Get the output stream for writing PDF object        
	      OutputStream out=null;
		try {
			out = response.getOutputStream();
			List <PatientMst> pList=patientService.getPatientList();
			 Document document = new Document();
	           //Basic PDF Creation inside servlet 
	          PdfWriter.getInstance(document, out);
	          document.open();
	          Paragraph p=  new Paragraph("                       User Information ");
	          document.add(p);
	          Paragraph pBlank=  new Paragraph("                     ");
	          document.add(pBlank);
	        /*  PdfPTable table = new PdfPTable(4); // 3 columns.
	          PdfPCell cell1 = new PdfPCell(new Paragraph("Name"));
	          PdfPCell cell2 = new PdfPCell(new Paragraph("Password"));
	          PdfPCell cell3 = new PdfPCell(new Paragraph("Email"));
	          PdfPCell cell4 = new PdfPCell(new Paragraph("Email"));
	          PdfPCell cell5 = new PdfPCell(new Paragraph("Email"));
		         
	          table.addCell(cell1);
	          table.addCell(cell2);
	          table.addCell(cell3);
	          table.addCell(cell4);
	          table.addCell(cell5);
	        */  /*for(PatientMst e:pList){
	        	  PdfPCell  cellName = new PdfPCell(new Phrase(e.getName()));
	        	  table.addCell(cellName);
	        	  
	          }*/
	         // document.add(table);
	          //PdfPTable table = new PdfPTable(5);
	           PdfPTable table = new PdfPTable(3); // 3 columns.
	           table.setSpacingBefore(10);
		          table.setSpacingAfter(10);
		        
	          PdfPCell cell1 = new PdfPCell(new Paragraph("Name"));
	          PdfPCell cell2 = new PdfPCell(new Paragraph("Password"));
	          PdfPCell cell3 = new PdfPCell(new Paragraph("Email"));
	          table.addCell(cell1);
	          table.addCell(cell2);
	          table.addCell(cell3);
	         /*for (int i = 1; i <= 15; i++) {
	        	 table.addCell("cell");
	          }*/
	          for(PatientMst e:pList){
	        	  System.out.println(1);
	        	  table.addCell("cell");
	        	  System.out.println(e.getName());
	        	//  PdfPCell  cellName = new PdfPCell(new Phrase(e.getName()));
	        	 // String name=e.getName();
	        	  //table.addCell("cell");
	          }
	          document.add(table);
	         
	          
	         /* document.add(new Paragraph("Tutorial to Generate PDF using Servlet"));
	          document.add(new Paragraph("PDF Created Using Servlet, iText Example Works"));
	         */ document.close();
	     }catch(Exception ex){}

	 
   }

	
	
}
