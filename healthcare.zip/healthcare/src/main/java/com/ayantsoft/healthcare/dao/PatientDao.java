package com.ayantsoft.healthcare.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.FetchMode;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.ayantsoft.hibernate.pojo.CategoryMst;
import com.ayantsoft.hibernate.pojo.PatientMst;

@Repository
public class PatientDao {
	
	@Autowired
	private HibernateTemplate hibernateTemplate; 
   
	@Transactional
	public boolean insertPatient(PatientMst patientMst){
		try{
		System.out.println(patientMst.getDoa());
		hibernateTemplate.save(patientMst.getAddressMst());
		hibernateTemplate.save(patientMst);
		return true;
		}catch(Exception ex){
			System.out.print("========");
			ex.printStackTrace();
			System.out.print(ex.getMessage());
			return false;
		}

	}
	
	public List<CategoryMst> getCategory(){
		try{
			DetachedCriteria criteria = DetachedCriteria.forClass(CategoryMst.class,"CATEGORY");
			@SuppressWarnings("unchecked")
		    List<CategoryMst> results = (List<CategoryMst>)hibernateTemplate.findByCriteria(criteria);
			return results;
		}catch(Exception ex){
			return null;
		}

	}
	
	public List<PatientMst> getPatientList(){
		try{
			System.out.println("====="+1);
			DetachedCriteria criteria = DetachedCriteria.forClass(PatientMst.class,"PT");
			 criteria.createAlias("PT.addressMst", "ADD");
			 List <PatientMst>pList=(List<PatientMst>) hibernateTemplate.findByCriteria(criteria);
			 System.out.println("====="+2);
			 return pList;
		}catch(Exception ex){
			return null;
		}
	}
}
