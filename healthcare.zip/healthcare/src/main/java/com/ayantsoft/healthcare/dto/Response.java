package com.ayantsoft.healthcare.dto;

public class Response {
	boolean res;
	
	//getter and setter
	public boolean isRes() {
		return res;
	}

	public void setRes(boolean res) {
		this.res = res;
	}
	
}
