package com.ayantsoft.healthcare.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;


import com.ayantsoft.hibernate.pojo.PatientMst;
import com.ayantsoft.hibernate.pojo.UserMst;



@Repository
public class LoginDao {

	@Autowired
	private HibernateTemplate hibernateTemplate; 
    
	
	public boolean checkUserInfo(UserMst userMst){
		boolean isUserAuthenticated=false;
		try{
			
			DetachedCriteria criteria = DetachedCriteria.forClass(UserMst.class,"USER");
				criteria.add(Restrictions.eq("USER.userName",userMst.getUserName()));
				
			@SuppressWarnings("unchecked")
			List<UserMst> results = (List<UserMst>)hibernateTemplate.findByCriteria(criteria);
			if(!results.isEmpty()){
				for(UserMst u:results){
					if(u.getPassword().equals(userMst.getPassword())){
						isUserAuthenticated=true;
					}else{
						isUserAuthenticated=false;
					}
				}
				
			}else{
				isUserAuthenticated=false;
			}
			 System.out.println(isUserAuthenticated);
			return isUserAuthenticated;
		}catch(Exception ex){
			return isUserAuthenticated;
		}
		finally{
			//space for cleanup code
		}
	}
	
}
