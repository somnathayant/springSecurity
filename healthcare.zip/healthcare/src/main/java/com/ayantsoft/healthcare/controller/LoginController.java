package com.ayantsoft.healthcare.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ayantsoft.healthcare.dto.Response;
import com.ayantsoft.healthcare.service.LoginService;
import com.ayantsoft.hibernate.pojo.UserMst;

@RestController
public class LoginController {

	@Autowired
	private LoginService loginService;
	
	 @RequestMapping("/")  
	    public ModelAndView welcome() {  
	   ModelAndView mv=new ModelAndView();
	   UserMst user=new UserMst();
		 mv.setViewName("login");
		 mv.addObject("user",user);
		 return mv;
		}  
	
	 @RequestMapping(value={"/checkLogin"},method={RequestMethod.POST})  
	    public ModelAndView checkLogin(@ModelAttribute("user")UserMst userMst) {  
		 boolean isUserAuthenticated=false;
		 ModelAndView mv=new ModelAndView();
		 isUserAuthenticated=loginService.userCheckInfo(userMst);
		 Response res=new Response();
		 if(isUserAuthenticated){
			 mv.setViewName("home");
			 return mv;
		 }else{                                    //this is  code  checks from database
			 mv.setViewName("login");
			 mv.addObject("loginCrd", "NOt Authenticated");
			 return mv;
		 }	 
	 }  
	 
	 @RequestMapping("/home")  
	    public ModelAndView home() {  
	   ModelAndView mv=new ModelAndView();
	 	 mv.setViewName("home");
		 return mv;
		}  
	 	 
}
